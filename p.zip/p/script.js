let basic_q = false;
let recognition;
let speechTimeout;
let finalTranscript = '';
let userSpoke = false;
let interviewTimer;
let isInterviewActive = false;
const interviewDuration = 120; // Duration in seconds for the interview

const interviewerAvatar = document.querySelector('.interviewer-avatar');
const userAvatar = document.querySelector('.user-avatar');
const startButton = document.getElementById('start');

startButton.addEventListener('click', () => {
  startInterview();
});

function startInterview() {
  if (isInterviewActive) return;

  isInterviewActive = true;
  callApi('intro', 'u', 'q');

  $("#start").prop("disabled", true);
  $("#start").text('Interview in progress...');


  interviewTimer = setTimeout(endInterview, interviewDuration * 1000);
}

function endInterview() {
  isInterviewActive = false;
  clearTimeout(interviewTimer);

  if (recognition) {
    recognition.stop();
    recognition = null;
  }

  updateInterviewerStatus(false);
  updateUserStatus(false);

  $("#start").text('Thank you for your time! The interview has ended.');
  document.getElementById('captured-text').textContent = '';

  $.ajax({url: 'end_session.php'});

}

function callApi(p, u, q) {
  if (!isInterviewActive) return;

  const data = { p, u, q };

  $.ajax({
    url: 'start.php',
    data: $.param(data),
    success(result) {
      if (isInterviewActive) {
        document.getElementById('intro_q').textContent = `Interviewer: ${result}`;
	console.log('Interviewer: ' + result);
        speakText(result);
      }
    },
    error(err) {
      console.error('API call failed:', err);
    },
  });
}

function startListening() {
  recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
  recognition.lang = 'en-US';
  recognition.interimResults = true;
  recognition.continuous = true;

  finalTranscript = '';
  userSpoke = false;

  recognition.start();
  updateUserStatus(true);

  recognition.onresult = (event) => {
    clearTimeout(speechTimeout);
    userSpoke = true;

    let interimTranscript = '';
    for (let i = event.resultIndex; i < event.results.length; i++) {
      const transcript = event.results[i][0].transcript;
      if (event.results[i].isFinal) {
        finalTranscript += transcript + ' ';
      } else {
        interimTranscript += transcript;
      }
    }

    document.getElementById('captured-text').textContent = `User: ${finalTranscript.trim() || interimTranscript.trim()}`;
    console.log('User: ' + $('#captured-text').text());
    speechTimeout = setTimeout(() => handleSpeechEnd(finalTranscript.trim()), 3000);
  };

  recognition.onerror = (event) => {
    console.error('Error occurred:', event.error);
    document.getElementById('captured-text').textContent = `Error: ${event.error}`;
  };

  recognition.onend = () => {
    updateUserStatus(false);
    if (!isInterviewActive) return;
    if (!speechTimeout) handleSpeechEnd(finalTranscript.trim());
    recognition.start();
  };
}

function handleSpeechEnd(finalTranscript) {
  clearTimeout(speechTimeout);
  speechTimeout = null;

  if (userSpoke && finalTranscript) {
    if (!basic_q) {
      callApi('basic_q', 'u', finalTranscript);
      basic_q = true;
    } else {
      const q = document.getElementById('intro_q').textContent.replace('Interviewer: ', '');
      callApi('followup_q', finalTranscript, q);
    }
    finalTranscript = '';
  } else {
    document.getElementById('captured-text').textContent = 'User: No input detected.';
  }
}

function speakText(text) {
  const utterance = new SpeechSynthesisUtterance(text);
  updateInterviewerStatus(true);

  utterance.onend = () => {
    updateInterviewerStatus(false);
    if (isInterviewActive) startListening();
  };

  speechSynthesis.speak(utterance);
}

function updateInterviewerStatus(isSpeaking) {
  interviewerAvatar.classList.toggle('active', isSpeaking);
}

function updateUserStatus(isSpeaking) {
  userAvatar.classList.toggle('active', isSpeaking);
}
