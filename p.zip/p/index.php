<?php
@session_start();

if(isset($_SESSION['uid']) && !empty($_SESSION['uid'])) {
	header("Location: intro.php");
	exit; // Always call exit after a redirect to stop further script execution
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Welcome to AI Interview</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <div class="welcome-container">
    <h2>Welcome to the AI-based Interviewer</h2>
    <p class="instructions">
      Please enter your User ID below to start the discussion. Make sure your microphone is working and you are in a quiet environment for the best experience.
    </p>
    <form method="post" action="session.php" class="welcome-form">
      <input type="text" name="uid" class="uid" placeholder="Enter your User ID" required>
      <input type="submit" id="start" value="Next Step">
    </form>
  </div>
</body>
</html>

<style>
.welcome-container{
width: 60%;
    margin: 0 auto;
}
.uid{
padding: 5px;
}
#start{
    padding: 4.5px;
}
</style>
