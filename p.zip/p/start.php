<?php
@session_start();

//echo 'hello hello ';

//exit();

@$p = $_GET['p'];
@$u = $_GET['u'];
@$q = $_GET['q'];

$message = '';

if($p == 'intro') {
    $message = "Please ask exactly this question - Hi Anil, brief about your technical experience, especially Salesfroce related.";
}else if($p == 'basic_q'){ 
    $message = "Generate a single, concise question about Salesforce architecture e.g data model, integrations etc. Do not include any additional text, explanations, or introductions. Just provide the question.";
}else if($p == 'followup_q'){ 
    $message = "Based on the question you asked to the candidate, and based on answer given by candidate, ask followup question. Do not include any additional text, explanations, or introductions. The question you asked was: ".$q." and the candidate answer was ".$u. " Also, evaluate candidate answer on accuracy and retrun in this format e.g ***R:4*** with 5 being the highest.";

if(isset($q) && isset($u)) {
$file = 'admin/results/'.$_SESSION['uid'] . '.txt';
$data = 'Question: ' . $q . "\nAnswer: " . $u . "\n"."Rating:".@$_SESSION['rating']."\n\n\n"; 

$fileHandle = fopen($file, 'a'); // 'w' mode overwrites the file; use 'a' to append

if ($fileHandle) {
    // Write data to the file
    fwrite($fileHandle, $data);
    fclose($fileHandle);
} else {
    //echo "Unable to open the file.";
}
} // write end


}

$messages = [
    ["role" => "system", "content" => "You are an expert human like interviewer evaluating candidates."],
    ["role" => "user", "content" => $message]
];


$res = callOpenAI($messages, $apiKey);
echo $res;

function callOpenAI($messages, $apiKey) {
    $url = "https://api.openai.com/v1/chat/completions";
    $data = [
        "model" => "gpt-4o-mini",
        "messages" => $messages,
        "temperature" => 0.7,
        "max_tokens" => 150
    ];

    // Initialize cURL
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Content-Type: application/json",
        "Authorization: Bearer $apiKey"
    ]);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

    // Execute and handle response
    $response = curl_exec($ch);
    if (curl_errno($ch)) {
        echo "Error: " . curl_error($ch);
        return null;
    }
    curl_close($ch);

    $data = json_decode($response, true);
    $content = $data['choices'][0]['message']['content'];

$_SESSION['rating'] = substr($content, -9);

    $content = substr($content, 0, -9);

return $content;

}

?>