<?php

@session_start();

// Database configuration
$host = "localhost";
$username = "i_user";
$password = "content";
$database = "interview";

// Create connection
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
//echo "Connected successfully";



?>