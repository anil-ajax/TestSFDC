<?php

$uid = $_POST['uid'];

$conn = new mysqli('localhost', 'root', '', 'interview');

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Validate login credentials
    $sql = "SELECT * FROM candidates WHERE id = '$uid' limit 1";
    $result = $conn->query($sql);
$row = $result->fetch_assoc();




@session_start();

$_SESSION['uid'] = $uid;
$_SESSION['uname'] = $row['name'];


header("Location: intro.php");
exit; // Always call exit after a redirect to stop further script execution

?>