<?php
session_start();

if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $primary_skill = $_POST['primary_skill'];
    $secondary_skill = $_POST['secondary_skill'];
$admin_id = $_SESSION['admin_id'];

    // Connect to DB
    $conn = new mysqli('localhost', 'root', '', 'interview');

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Insert new candidate
    $sql = "INSERT INTO candidates (name, primary_skill, secondary_skill, admin_id) VALUES ('$name', '$primary_skill', '$secondary_skill', '$admin_id')";

    if ($conn->query($sql) === TRUE) {
        header('Location: dashboard.php');
    } else {
        $error_message = "Error: " . $conn->error;
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Candidate</title>
</head>
<body>
    <h1>Add New Candidate</h1>
    <a href="dashboard.php">Back to Dashboard</a>

    <form method="POST" action="add_candidate.php">
        <label for="name">Name:</label>
        <input type="text" name="name" required><br>
        <label for="primary_skill">Primary Skill:</label>
        <input type="text" name="primary_skill" required><br>
        <label for="secondary_skill">Secondary Skill:</label>
        <input type="text" name="secondary_skill" required><br>
        <button type="submit">Add Candidate</button>
    </form>
    <?php if (isset($error_message)) { echo $error_message; } ?>
</body>
</html>
