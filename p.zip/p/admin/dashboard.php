<?php
session_start();

if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit();
}

// Connect to DB
$conn = new mysqli('localhost', 'root', '', 'interview');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch candidates
$sql = "SELECT * FROM candidates";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
</head>
<body>
    <h1>Welcome to Admin Dashboard</h1>
    <a href="logout.php">Logout</a>

    <h2>List of Candidates</h2>
    <table border="1">
        <thead>
            <tr>
                <th>Name</th>
                <th>Primary Skill</th>
                <th>Secondary Skill</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo $row['name']; ?></td>
                    <td><?php echo $row['primary_skill']; ?></td>
                    <td><?php echo $row['secondary_skill']; ?></td>
<td><?php echo $row['id']; ?></td>
<td><a href="results/<?php echo $row['id']; ?>.txt">Result</a></td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
    <a href="add_candidate.php">Add New Candidate</a>
</body>
</html>

<?php $conn->close(); ?>
